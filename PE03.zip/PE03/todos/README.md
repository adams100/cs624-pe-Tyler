## Input

- User Adds a item to the todo box and presses add todo

---

## Process

- the todo is added to the list within the applicaiton 
- other actions are configured such as filters, delete or marking a todo as done

---

## Output

- the todo is listed on the application once processing is complete. 
- If the user deletes the todo, it is removed from the list
